<?php
define("HOST_SS", "localhost");
define("PORT_SS", 3306);
define("USER_SS", "root");
define("PASS_SS", "");
define("DB_SS", "vitainsumos");
?>