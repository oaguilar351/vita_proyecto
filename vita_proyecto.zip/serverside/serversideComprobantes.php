<?php require ("serverside.php") ?>
<?php 
$table_data -> get('vit_comprobantes', 'Cfdi_ID', array('Cfdi_Version','Cfdi_Serie','c_Moneda','Emi_RFC','Rec_RFC','Cfdi_UUID','Cfdi_Status'));
?>